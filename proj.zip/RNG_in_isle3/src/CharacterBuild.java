import java.util.Scanner;
public class CharacterBuild {
	private String kline;
	private int Strength, Speed, Reflex, Charm, Confidence, Leadership;
	int[] mainAbilities = {Strength, Speed, Reflex,};
	int[] sideAbilities = {Leadership, Charm, Confidence};
//constructors
	    public CharacterBuild() {
	        mainAbilities = new int[]{0, 0, 0};
	        sideAbilities = new int[]{0, 0, 0};
	    }  
	    
private Scanner s = new Scanner(System.in);
private int kchoice =0;




	public int[] haracterBuild(int e) {
System.out.println("These choices will determine your abilities while working, choose wisely!");

System.out.println("After school class in kindergarten!");
System.out.println("You are being taught thermodynamics by a strange looking 22 year old, who is somehow making the concepts understandable.");
System.out.println("");
System.out.println("		During the class you choose to:");
System.out.println("(1) Listen quietly and enjoy the activities.");
System.out.println("(2) Do you best to help the teacher when you can, enjoy the class and help others with difficult tasks (like inflating balloons)");
System.out.println("(3) Ignore all rules and run around the classroom, hiding under desks etc.");
kchoice = s.nextInt();
if (!(kchoice==1 || kchoice==2|| kchoice==3)) {
System.out.println("You are so into not following rules you didnt even enter a proper response! (enter 1, 2, or 3)");
System.out.println("Nothing of value was gained as a result.");
}
else {
	
	switch (kchoice) {
	case 1:
		kline="Listen";
		break;
	case 2:
		kline="Do";
		break;
	case 3:
		kline="Ignore";
		break;
	}
	System.out.println("you decide to " + kline);
}






return mainAbilities;
	
	}
}
//Kaiyytelynn